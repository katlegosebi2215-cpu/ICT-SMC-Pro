# ICT/SMC Pro v4.0

Android WebView app containing the corrected ICT/SMC signal scanner.

## Included
- Deriv WebSocket OHLC connection
- M1 / M5 / M15 / H1 analysis
- FVG / IFVG
- BOS / CHoCH
- Liquidity sweeps
- Premium / Discount
- Order blocks
- Displacement
- Multi-timeframe confluence
- Weltrade-style simulation (not a live Weltrade API)

## Build
Push the project to GitHub, open **Actions**, run **Build ICT-SMC Pro APK**, then download the `ICT-SMC-Pro-debug` artifact.
